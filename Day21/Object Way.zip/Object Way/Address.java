public class Address
{
	String cityname;
	String areaname;
	int pincode;
}