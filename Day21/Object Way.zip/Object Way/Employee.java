public class Employee
{
	int eid;
	String ename;
	float esalary;
	Address a;
}