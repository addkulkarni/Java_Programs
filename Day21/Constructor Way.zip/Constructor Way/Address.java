public class Address
{
	String cityname;
	String areaname;
	int pincode;
	
	public Address(String cityname,String areaname,int pincode)
	{
		this.cityname=cityname;
		this.areaname=areaname;
		this.pincode=pincode;
	}
}