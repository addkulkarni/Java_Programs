public class Employee
{
	int eid;
	String ename;
	float esalary;
	Address a;
	
	public Employee(int eid,String ename,float esalary,Address a)
	{
		this.eid=eid;
		this.ename=ename;
		this.esalary=esalary;
		this.a=a;
	}
}